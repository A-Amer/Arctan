package com.example.amira.sb;

import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;

/**
 * Created by amira on 4/30/17.
 */

public class GetLocation implements android.location.LocationListener {

    public double latitude;
    public double longitude;
    @Override
    public void onLocationChanged(Location location) {
        latitude = location.getLatitude();
        longitude = location.getLongitude();

    }
    public int GetIndex()
    {
        int x;
        x = 6;
        //connect to cloud
        return x;
    }
    public String UIVdesc(int UVI)
    {
        if(UVI<3)
            return "LOW";
        else if (UVI <6)
            return "MODERATE";
        else if (UVI<8)
            return "HIGH";
        else if (UVI < 11)
            return "VERY HIGH";
        else
            return "Extreme";
    }
    public boolean GetHAPS()
    {
        boolean b;
        b=true;
        return b;
    }
    public String Precautions(int UVI)
    {
        if(UVI<3)
            return "LOW";
        else if (UVI <6)
            return "MODERATE";
        else if (UVI<8)
            return "HIGH";
        else if (UVI < 11)
            return "VERY HIGH";
        else
            return "Extreme";
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }
    public void getlocation (Location location)
    {
    }
}
