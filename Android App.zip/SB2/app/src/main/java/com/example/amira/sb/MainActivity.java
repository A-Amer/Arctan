package com.example.amira.sb;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;



public class MainActivity extends AppCompatActivity  {

    protected String precau[] = new String[6];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        precau[0]="Remember to wear your sunglasses, a wide-brimmed hat ";
        precau[1]="Shade is one of the best defences against the sun’s radiation. Try to find some shade.";
        precau[2]="Consider Wearing protective clothing";
        precau[3]="frequently apply sunscreen of SPF 15+";
        precau[4]="Wanna have fun and UV is high?After 4pm=light+less UV!Staay shaded for now!";
        precau[5]="frequently apply sunscreen of SPF 15+";


    }

}
